const Controller = require('../Controller')
const JoiValidator = require('../Lib/joiValidator')

module.exports=[
    {
 
        path:'/api/user/createbooking',
        method:'POST',
        // config:{
        //     validate: {
        //         payload: JoiValidator.createBooking()
        //     },
        // },
        async handler(req, res) {
            try{
                const response = await Controller.BookingController.userBooking(req)
               
                return response
            }
            catch(error)
            {
                console.log(error);
                throw error
            }
            
        }
    },
    {
        path : '/api/user/getBooking',
        method : 'POST',
        async handler(req,res){
            try{
            const response = await Controller.BookingController.getBookingById(req)
            return response
            }catch(error){
                throw error;
            }
        }
    },   

]