const userRoutes = require('./users')
const bookingRoutes = require('./booking')

module.exports = 
{
    userRoutes:userRoutes,
    bookingRoutes:bookingRoutes
}

