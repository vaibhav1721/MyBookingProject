const UserService = require('./users')
const BookingService = require('./booking')
module.exports = {
    UserService: UserService,
    BookingService:BookingService
}

