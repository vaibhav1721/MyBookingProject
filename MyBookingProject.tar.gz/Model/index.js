const UserModel = require('./userModel')
const BookingModel=require('./bookingModel')

module.exports = {
    UserModel: UserModel,
    BookingModel:BookingModel
}