const UserController = require('./users')
const BookingController = require('./booking')
module.exports = {
    UserController: UserController,
    BookingController:BookingController
}

