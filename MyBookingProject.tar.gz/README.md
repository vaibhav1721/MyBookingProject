# strictjs
Node js framework
