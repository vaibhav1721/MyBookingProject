
const Routes = require('./Routes') 

const Hapi = require('hapi')
const db = require('./dbconnection')
// const Config = require('./Config')
// const BootStrap = require('./Util/bootStrap.js')


const server=Hapi.server({
    host:'localhost',
    port:'4500'
})
server.route(Routes.userRoutes)
server.route(Routes.bookingRoutes)
async function connectDatabase() {
    try {
       await server.start();
       console.log(`the sever is started :${server.info.uri}`)

      let database = await db.dbConnection()
        global.DATABASE = database

    } catch (err){
        console.log(err)
    }

}
connectDatabase();










